//
//  Venues+CoreDataClass.swift
//  
//
//  Created by Abhi on 06/09/21.
//
//

import Foundation
import CoreData

@objc(Venues)
public class Venues: NSManagedObject {

}
